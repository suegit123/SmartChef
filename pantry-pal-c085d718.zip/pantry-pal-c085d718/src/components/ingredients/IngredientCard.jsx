import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, AlertCircle } from "lucide-react";
import { differenceInDays, format } from "date-fns";

const categoryColors = {
  vegetables: "bg-green-100 text-green-800 border-green-300",
  fruits: "bg-red-100 text-red-800 border-red-300",
  meat: "bg-rose-100 text-rose-800 border-rose-300",
  seafood: "bg-blue-100 text-blue-800 border-blue-300",
  dairy: "bg-yellow-100 text-yellow-800 border-yellow-300",
  grains: "bg-amber-100 text-amber-800 border-amber-300",
  seasonings: "bg-purple-100 text-purple-800 border-purple-300",
  oils: "bg-orange-100 text-orange-800 border-orange-300",
  herbs: "bg-lime-100 text-lime-800 border-lime-300",
  other: "bg-gray-100 text-gray-800 border-gray-300"
};

export default function IngredientCard({ ingredient, onClick }) {
  const daysUntilExpiry = ingredient.expiry_date 
    ? differenceInDays(new Date(ingredient.expiry_date), new Date())
    : null;
  
  const isExpiringSoon = daysUntilExpiry !== null && daysUntilExpiry <= 3 && daysUntilExpiry >= 0;
  const isExpired = daysUntilExpiry !== null && daysUntilExpiry < 0;

  return (
    <Card 
      className="group cursor-pointer hover:shadow-xl transition-all duration-300 border-none overflow-hidden"
      onClick={onClick}
    >
      {ingredient.photo_url && (
        <div className="relative h-48 overflow-hidden">
          <img 
            src={ingredient.photo_url} 
            alt={ingredient.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          {(isExpiringSoon || isExpired) && (
            <div className={`absolute top-3 right-3 ${isExpired ? 'bg-red-500' : 'bg-orange-500'} text-white px-3 py-1 rounded-full flex items-center gap-1 text-sm font-medium shadow-lg`}>
              <AlertCircle className="w-4 h-4" />
              {isExpired ? 'Expired' : `${daysUntilExpiry}d left`}
            </div>
          )}
        </div>
      )}
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-bold text-lg text-gray-900 mb-1">{ingredient.name}</h3>
            {ingredient.quantity && (
              <p className="text-sm text-gray-600">{ingredient.quantity} {ingredient.unit}</p>
            )}
          </div>
          <Badge className={`${categoryColors[ingredient.category]} border`}>
            {ingredient.category}
          </Badge>
        </div>
        
        {ingredient.expiry_date && (
          <div className="flex items-center gap-2 text-sm text-gray-500 mt-3 pt-3 border-t border-gray-100">
            <Calendar className="w-4 h-4" />
            <span>Expires {format(new Date(ingredient.expiry_date), "MMM d, yyyy")}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}