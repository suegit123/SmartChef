
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, Trash2, Package, Share2, Minus, Plus } from "lucide-react";
import { format } from "date-fns";
import CreatePostDialog from '../community/CreatePostDialog';
import { Ingredient, CommunityPost } from '@/api/entities';

const categoryColors = {
  vegetables: "bg-green-100 text-green-800",
  fruits: "bg-red-100 text-red-800",
  meat: "bg-rose-100 text-rose-800",
  seafood: "bg-blue-100 text-blue-800",
  dairy: "bg-yellow-100 text-yellow-800",
  grains: "bg-amber-100 text-amber-800",
  seasonings: "bg-purple-100 text-purple-800",
  oils: "bg-orange-100 text-orange-800",
  herbs: "bg-lime-100 text-lime-800",
  other: "bg-gray-100 text-gray-800"
};

export default function IngredientDetailsDialog({ ingredient, onClose, onDelete, onUpdate }) {
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [currentQuantity, setCurrentQuantity] = useState(parseFloat(ingredient.quantity) || 0);

  const handleShareSubmit = async (postData) => {
    await CommunityPost.create({
      ...postData,
      category: ingredient.category || 'other',
      status: "available",
    });
    setShowShareDialog(false);
    alert("Ingredient shared successfully!");
  };

  const updateQuantity = async (newQuantity) => {
    if (newQuantity < 0) newQuantity = 0;
    setCurrentQuantity(newQuantity);
    await Ingredient.update(ingredient.id, { quantity: String(newQuantity) });
    onUpdate(); // Refresh the list in the parent
  };
  
  if (showShareDialog) {
    return (
      <CreatePostDialog
        onClose={() => setShowShareDialog(false)}
        onSubmit={handleShareSubmit}
        initialData={{
          ingredient_name: ingredient.name,
          quantity: `${ingredient.quantity} ${ingredient.unit}`,
          expiry_date: ingredient.expiry_date,
          photo_url: ingredient.photo_url
        }}
      />
    );
  }

  return (
    <Dialog open={!!ingredient && !showShareDialog} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{ingredient.name}</DialogTitle>
        </DialogHeader>
        
        {ingredient.photo_url && (
          <div className="w-full h-64 rounded-xl overflow-hidden">
            <img 
              src={ingredient.photo_url} 
              alt={ingredient.name}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        <div className="space-y-4">
          <div className="flex items-start justify-between">
            <Badge className={categoryColors[ingredient.category]}>
              {ingredient.category}
            </Badge>
            {ingredient.quantity && (
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(currentQuantity - 1)}><Minus className="h-4 w-4" /></Button>
                <span className="text-gray-800 font-bold text-lg w-20 text-center flex items-center justify-center gap-1">
                  <Package className="w-4 h-4" />
                  {currentQuantity} {ingredient.unit}
                </span>
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(currentQuantity + 1)}><Plus className="h-4 w-4" /></Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
            {ingredient.purchase_date && (
              <div>
                <p className="text-sm text-gray-500 flex items-center gap-1 mb-1">
                  <Calendar className="w-4 h-4" />
                  Purchased
                </p>
                <p className="font-medium">{format(new Date(ingredient.purchase_date), "MMM d, yyyy")}</p>
              </div>
            )}
            {ingredient.expiry_date && (
              <div>
                <p className="text-sm text-gray-500 flex items-center gap-1 mb-1">
                  <Calendar className="w-4 h-4" />
                  Expires
                </p>
                <p className="font-medium">{format(new Date(ingredient.expiry_date), "MMM d, yyyy")}</p>
              </div>
            )}
          </div>

          {ingredient.storage_location && (
            <div className="flex items-center gap-2 text-gray-600">
              <MapPin className="w-4 h-4" />
              <span>Stored in: {ingredient.storage_location}</span>
            </div>
          )}

          {ingredient.notes && (
            <div className="p-4 bg-emerald-50 rounded-xl">
              <p className="text-sm font-medium text-gray-700 mb-1">Notes</p>
              <p className="text-gray-600">{ingredient.notes}</p>
            </div>
          )}
        </div>

        <DialogFooter className="justify-between">
          <div>
            <Button
              variant="outline"
              onClick={() => setShowShareDialog(true)}
            >
              Share Ingredient
            </Button>
          </div>
          <div className="flex gap-2">
            <Button
              variant="destructive"
              onClick={() => onDelete(ingredient.id)}
              className="flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </Button>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
