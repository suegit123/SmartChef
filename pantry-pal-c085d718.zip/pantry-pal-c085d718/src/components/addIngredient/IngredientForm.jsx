import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Save, Loader2 } from "lucide-react";

const categories = ["vegetables", "fruits", "meat", "seafood", "dairy", "grains", "seasonings", "oils", "herbs", "other"];

export default function IngredientForm({ ingredients, onSave, onCancel, processing }) {
  const [items, setItems] = useState(ingredients);

  const updateItem = (index, field, value) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const removeItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-6">
      {items.map((item, index) => (
        <Card key={index} className="border-none shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Ingredient {index + 1}</CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => removeItem(index)}
            >
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="grid md:grid-cols-2 gap-4">
            <div>
              <Label>Name *</Label>
              <Input
                value={item.name || ''}
                onChange={(e) => updateItem(index, 'name', e.target.value)}
                placeholder="e.g., Tomatoes"
              />
            </div>
            <div>
              <Label>Category *</Label>
              <Select
                value={item.category || ''}
                onValueChange={(value) => updateItem(index, 'category', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Quantity</Label>
              <Input
                value={item.quantity || ''}
                onChange={(e) => updateItem(index, 'quantity', e.target.value)}
                placeholder="e.g., 2, 500"
              />
            </div>
            <div>
              <Label>Unit</Label>
              <Input
                value={item.unit || ''}
                onChange={(e) => updateItem(index, 'unit', e.target.value)}
                placeholder="e.g., kg, pieces, liters"
              />
            </div>
            <div>
              <Label>Purchase Date</Label>
              <Input
                type="date"
                value={item.purchase_date || ''}
                onChange={(e) => updateItem(index, 'purchase_date', e.target.value)}
              />
            </div>
            <div>
              <Label>Expiry Date</Label>
              <Input
                type="date"
                value={item.expiry_date || ''}
                onChange={(e) => updateItem(index, 'expiry_date', e.target.value)}
              />
            </div>
            <div>
              <Label>Storage Location</Label>
              <Input
                value={item.storage_location || ''}
                onChange={(e) => updateItem(index, 'storage_location', e.target.value)}
                placeholder="e.g., Fridge, Pantry"
              />
            </div>
            <div className="md:col-span-2">
              <Label>Notes</Label>
              <Textarea
                value={item.notes || ''}
                onChange={(e) => updateItem(index, 'notes', e.target.value)}
                placeholder="Any additional information..."
              />
            </div>
          </CardContent>
        </Card>
      ))}

      <Card className="border-none shadow-lg">
        <CardFooter className="flex justify-end gap-3 pt-6">
          <Button variant="outline" onClick={onCancel} disabled={processing}>
            Cancel
          </Button>
          <Button
            className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
            onClick={() => onSave(items)}
            disabled={processing || items.length === 0}
          >
            {processing ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-5 h-5 mr-2" />
                Save All Ingredients
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}