import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChefHat, Clock, Flame, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";

export default function RecentRecipes({ recipes, onDelete }) {
  if (recipes.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChefHat className="w-5 h-5 text-emerald-500" />
            Saved Recipes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-gray-500 mb-4">No saved recipes yet</p>
            <Link to={createPageUrl("RecipeChat")}>
              <Button variant="outline" className="border-emerald-500 text-emerald-600 hover:bg-emerald-50">
                Generate Your First Recipe
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ChefHat className="w-5 h-5 text-emerald-500" />
          Saved Recipes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {recipes.map((recipe) => {
            const recipeForPrint = {
              ...recipe,
              ingredients: recipe.ingredients_used,
            };
            const recipeQuery = encodeURIComponent(JSON.stringify(recipeForPrint));
            
            return (
              <div key={recipe.id} className="group relative">
                <Link to={`${createPageUrl("RecipePrint")}?recipe=${recipeQuery}`} className="block">
                  <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 hover:shadow-md hover:border-emerald-300 transition-all">
                    <h4 className="font-semibold text-gray-900 mb-2">{recipe.name}</h4>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      {recipe.cook_time && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {recipe.cook_time}
                        </span>
                      )}
                      {recipe.calories && (
                        <span className="flex items-center gap-1">
                          <Flame className="w-3 h-3" />
                          {recipe.calories} cal
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
                <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 h-8 w-8 rounded-full bg-red-100 text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => {
                        e.stopPropagation();
                        onDelete(recipe.id);
                    }}
                >
                    <Trash2 className="w-4 h-4"/>
                </Button>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}