import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Package, AlertCircle, ChefHat } from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function QuickStats({ totalIngredients, expiringCount, recipesCount }) {
  const stats = [
    {
      title: "Total Ingredients",
      value: totalIngredients,
      icon: Package,
      color: "from-emerald-500 to-emerald-600",
      bgColor: "bg-emerald-100",
      link: createPageUrl("Ingredients")
    },
    {
      title: "Expiring Soon",
      value: expiringCount,
      icon: AlertCircle,
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-100"
    },
    {
      title: "Saved Recipes",
      value: recipesCount,
      icon: ChefHat,
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-100"
    },
  ];

  const StatCard = ({ stat }) => (
    <Card className="border-none shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500 mb-1">{stat.title}</p>
            <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
          </div>
          <div className={`p-4 rounded-2xl ${stat.bgColor}`}>
            <stat.icon className={`w-6 h-6 bg-gradient-to-br ${stat.color} bg-clip-text text-transparent`} 
              style={{ WebkitTextFillColor: 'transparent', WebkitBackgroundClip: 'text' }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {stats.map((stat) =>
        stat.link ? (
          <Link to={stat.link} key={stat.title}>
            <StatCard stat={stat} />
          </Link>
        ) : (
          <StatCard key={stat.title} stat={stat} />
        )
      )}
    </div>
  );
}