import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CommunityPost, Ingredient, Conversation, Notification } from "@/api/entities";
import { Heart, MessageCircle, MapPin, Clock, Trash2, Check } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import PostDetailsDialog from './PostDetailsDialog';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const categoryColors = {
  vegetables: "bg-green-100 text-green-800",
  fruits: "bg-red-100 text-red-800",
  default: "bg-gray-100 text-gray-800",
};

export default function CommunityPostCard({ post, postUser, currentUser, onUpdate }) {
  const [showDetails, setShowDetails] = React.useState(false);
  const navigate = useNavigate();

  const handleLike = async () => {
    const isLiked = post.likes.includes(currentUser.email);
    const newLikes = isLiked
      ? post.likes.filter(email => email !== currentUser.email)
      : [...post.likes, currentUser.email];
    
    await CommunityPost.update(post.id, { likes: newLikes });
    
    if (!isLiked && post.created_by !== currentUser.email) {
      await Notification.create({
        recipient_email: post.created_by,
        actor_email: currentUser.email,
        type: 'like',
        post_id: post.id,
        message: `${currentUser.full_name} liked your post for ${post.ingredient_name}.`
      });
    }
    
    onUpdate();
  };
  
  const handleContact = async () => {
    const participants = [currentUser.email, post.created_by].sort();
    
    const existingConvos = await Conversation.filter({ participants: participants });

    if (existingConvos.length > 0) {
      navigate(createPageUrl(`CommunityChat?conversationId=${existingConvos[0].id}`));
    } else {
      const newConvo = await Conversation.create({ participants });
      navigate(createPageUrl(`CommunityChat?conversationId=${newConvo.id}`));
    }
  };

  const handleClaim = async () => {
    if (!window.confirm("Are you sure you want to claim this item? It will be added to your pantry.")) return;
    try {
      await Ingredient.create({
        name: post.ingredient_name,
        category: post.category,
        quantity: post.quantity,
        photo_url: post.photo_url,
        purchase_date: new Date().toISOString().split('T')[0],
        expiry_date: post.expiry_date,
        notes: `Claimed from ${postUser?.full_name || 'the community'}`
      });

      await CommunityPost.update(post.id, { status: "claimed", claimed_by: currentUser.email });

      await Notification.create({
        recipient_email: post.created_by,
        actor_email: currentUser.email,
        type: 'claim',
        post_id: post.id,
        message: `${currentUser.full_name} claimed your ${post.ingredient_name}.`
      });

      alert("Item claimed and added to your pantry!");
      onUpdate();
    } catch (error) {
      console.error("Failed to claim item:", error);
      alert("There was an error claiming the item. Please try again.");
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this post? This action cannot be undone.")) return;
    try {
      await CommunityPost.delete(post.id);
      alert("Post deleted successfully.");
      onUpdate();
    } catch (error) {
      console.error("Failed to delete post:", error);
      alert("There was an error deleting the post. Please try again.");
    }
  };

  const isOwner = post.created_by === currentUser?.email;
  const hasLiked = post.likes.includes(currentUser?.email);

  return (
    <>
      <Card className="p-6 border-none shadow-lg hover:shadow-xl transition-shadow w-full">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src={postUser?.profile_picture_url} />
              <AvatarFallback>{postUser?.full_name?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-bold text-gray-800">{postUser?.full_name}</p>
              <div className="flex items-center gap-3 text-sm text-gray-500">
                {post.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3"/>{post.location}</span>}
                <span className="flex items-center gap-1"><Clock className="w-3 h-3"/>{formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}</span>
              </div>
            </div>
          </div>
          <Badge className={(categoryColors[post.category] || categoryColors.default) + ' self-start'}>
            {post.category}
          </Badge>
        </div>

        <div className="bg-emerald-50/70 p-4 rounded-lg mb-4">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-emerald-800">{post.ingredient_name}</h3>
            <Badge className="bg-emerald-600 text-white">Free</Badge>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            {post.quantity} &bull; Expires: {post.expiry_date ? format(new Date(post.expiry_date), 'P') : 'N/A'}
          </p>
        </div>
        
        <p className="text-gray-700 mb-4">{post.description}</p>

        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4 text-gray-600">
            <button onClick={handleLike} className="flex items-center gap-1.5 hover:text-red-500 transition-colors">
              <Heart className={`w-5 h-5 ${hasLiked ? 'text-red-500 fill-current' : ''}`} />
              {post.likes?.length || 0} Likes
            </button>
            <button onClick={() => setShowDetails(true)} className="flex items-center gap-1.5 hover:text-emerald-600 transition-colors">
              <MessageCircle className="w-5 h-5" />
              Comments ({post.comment_count || 0})
            </button>
          </div>
          {isOwner ? (
            <Button onClick={handleDelete} variant="destructive" size="sm">
              <Trash2 className="w-4 h-4 mr-1" /> Delete
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <Button onClick={handleClaim} variant="outline" size="sm">
                <Check className="w-4 h-4 mr-1"/> Claim
              </Button>
              <Button onClick={handleContact} className="bg-emerald-600 hover:bg-emerald-700">Contact</Button>
            </div>
          )}
        </div>
      </Card>
      {showDetails && <PostDetailsDialog post={post} postUser={postUser} currentUser={currentUser} onClose={() => setShowDetails(false)} onUpdate={onUpdate} />}
    </>
  );
}