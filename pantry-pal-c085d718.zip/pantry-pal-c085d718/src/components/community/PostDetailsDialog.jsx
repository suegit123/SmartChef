import React, { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Comment as CommentEntity, User, CommunityPost, Notification } from '@/api/entities';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatDistanceToNow } from 'date-fns';
import { Send, Loader2 } from 'lucide-react';

function CommentList({ postId, forceRefresh }) {
  const [comments, setComments] = useState([]);
  const [users, setUsers] = useState({});
  const [loading, setLoading] = useState(true);

  const fetchComments = useCallback(async () => {
    setLoading(true);
    const [commentsData, usersData] = await Promise.all([
      CommentEntity.filter({ post_id: postId }, "-created_date"),
      User.list()
    ]);
    setComments(commentsData);
    const usersMap = usersData.reduce((acc, user) => {
      acc[user.email] = user;
      return acc;
    }, {});
    setUsers(usersMap);
    setLoading(false);
  }, [postId]);

  useEffect(() => {
    fetchComments();
  }, [postId, forceRefresh, fetchComments]);
  
  if (loading) {
    return <div className="flex justify-center items-center py-4"><Loader2 className="animate-spin" /></div>;
  }
  
  if (comments.length === 0) {
    return <div className="text-center text-gray-500 py-4">No comments yet.</div>;
  }

  return (
    <div className="space-y-4 max-h-64 overflow-y-auto p-1">
      {comments.map(comment => {
        const commentUser = users[comment.created_by];
        return (
          <div key={comment.id} className="flex items-start gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={commentUser?.profile_picture_url} />
              <AvatarFallback>{commentUser?.full_name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <p className="font-semibold text-sm">{commentUser?.full_name}</p>
                <p className="text-xs text-gray-500">{formatDistanceToNow(new Date(comment.created_date), { addSuffix: true })}</p>
              </div>
              <p className="text-sm text-gray-700">{comment.content}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function PostDetailsDialog({ post, currentUser, onClose, onUpdate }) {
  const [newComment, setNewComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [refreshId, setRefreshId] = useState(0);

  const handleAddComment = async () => {
    if (!newComment.trim() || isSubmitting) return;
    setIsSubmitting(true);
    try {
      await CommentEntity.create({
        post_id: post.id,
        content: newComment,
      });

      const newCount = (post.comment_count || 0) + 1;
      await CommunityPost.update(post.id, { comment_count: newCount });

      if (post.created_by !== currentUser.email) {
        await Notification.create({
          recipient_email: post.created_by,
          actor_email: currentUser.email,
          type: 'comment',
          post_id: post.id,
          message: `${currentUser.full_name} commented on your post for ${post.ingredient_name}.`
        });
      }

      setNewComment("");
      setRefreshId(id => id + 1);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error("Failed to add comment:", error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDialogClose = () => {
    if (onUpdate) onUpdate();
    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={handleDialogClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Comments on "{post.ingredient_name}"</DialogTitle>
        </DialogHeader>
        <CommentList postId={post.id} forceRefresh={refreshId} />
        <DialogFooter className="border-t pt-4">
          <div className="flex w-full items-center gap-2">
            <Input 
              placeholder="Write a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddComment()}
              disabled={isSubmitting}
            />
            <Button onClick={handleAddComment} size="icon" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin"/> : <Send className="w-4 h-4"/>}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}