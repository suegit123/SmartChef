import React, { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Upload } from "lucide-react";
import { UploadFile } from "@/api/integrations";

export default function CreatePostDialog({ onClose, onSubmit, initialData = {} }) {
  const [formData, setFormData] = useState({
    ingredient_name: initialData.ingredient_name || "",
    quantity: initialData.quantity || "",
    location: initialData.location || "",
    expiry_date: initialData.expiry_date || "",
    description: initialData.description || "",
    photo_url: initialData.photo_url || ""
  });
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      setFormData(prev => ({ ...prev, photo_url: file_url }));
    } catch (error) {
      console.error("Error uploading file:", error);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = () => {
    if (!formData.ingredient_name || !formData.quantity) {
      alert("Please fill in ingredient name and quantity");
      return;
    }
    onSubmit(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Share an Ingredient</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {formData.photo_url ? (
            <div className="relative h-48 rounded-xl overflow-hidden">
              <img src={formData.photo_url} alt="Preview" className="w-full h-full object-cover" />
              <Button
                variant="secondary"
                size="sm"
                className="absolute top-3 right-3"
                onClick={() => setFormData(prev => ({ ...prev, photo_url: "" }))}
              >
                Change Photo
              </Button>
            </div>
          ) : (
            <>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button
                variant="outline"
                className="w-full h-32 border-2 border-dashed border-emerald-300 hover:bg-emerald-50"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? (
                  "Uploading..."
                ) : (
                  <>
                    <Camera className="w-6 h-6 mr-2" />
                    Add Photo (Optional)
                  </>
                )}
              </Button>
            </>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label>Ingredient Name *</Label>
              <Input
                value={formData.ingredient_name}
                onChange={(e) => setFormData(prev => ({ ...prev, ingredient_name: e.target.value }))}
                placeholder="e.g., Fresh Tomatoes"
              />
            </div>
            <div>
              <Label>Quantity *</Label>
              <Input
                value={formData.quantity}
                onChange={(e) => setFormData(prev => ({ ...prev, quantity: e.target.value }))}
                placeholder="e.g., 2 kg, 5 pieces"
              />
            </div>
            <div>
              <Label>Pickup Location</Label>
              <Input
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                placeholder="e.g., Downtown, Building 5"
              />
            </div>
            <div>
              <Label>Expiry Date</Label>
              <Input
                type="date"
                value={formData.expiry_date}
                onChange={(e) => setFormData(prev => ({ ...prev, expiry_date: e.target.value }))}
              />
            </div>
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Any additional details about the ingredient..."
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
            onClick={handleSubmit}
          >
            Share Ingredient
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}