
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Flame, Save, Download, Utensils, Users, ListOrdered, ShoppingBasket } from "lucide-react";

export default function RecipeSuggestion({ recipe, onSave, onExport, isSaved }) {
  return (
    <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 mt-4 -mx-2">
      <CardHeader>
        <CardTitle>{recipe.name}</CardTitle>
        {recipe.description && (
          <p className="text-gray-600 text-sm pt-1">{recipe.description}</p>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-700">
          {recipe.cook_time && (
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-emerald-600" />
              {recipe.cook_time}
            </span>
          )}
          {recipe.calories && (
            <span className="flex items-center gap-1">
              <Flame className="w-4 h-4 text-orange-600" />
              {recipe.calories} cal
            </span>
          )}
          {recipe.servings && (
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4 text-blue-600" />
              Serves {recipe.servings}
            </span>
          )}
          {recipe.cuisine && (
             <span className="flex items-center gap-1">
              <Utensils className="w-4 h-4 text-purple-600" />
              {recipe.cuisine}
            </span>
          )}
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {recipe.ingredients && (
            <div>
              <h4 className="font-semibold text-md mb-2 flex items-center gap-2"><ShoppingBasket className="w-5 h-5" />Ingredients</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-800">
                {recipe.ingredients.map((ing, index) => (
                  <li key={index}>{ing}</li>
                ))}
              </ul>
            </div>
          )}

          {recipe.instructions && (
            <div>
              <h4 className="font-semibold text-md mb-2 flex items-center gap-2"><ListOrdered className="w-5 h-5" />Instructions</h4>
              <ol className="list-decimal list-inside space-y-2 text-gray-800">
                {recipe.instructions.map((step, index) => (
                  <li key={index}>{step}</li>
                ))}
              </ol>
            </div>
          )}
        </div>

      </CardContent>
      <CardFooter className="flex justify-end gap-2">
         <Button
            size="sm"
            variant="outline"
            onClick={() => onExport(recipe)}
          >
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
          <Button
            size="sm"
            onClick={() => onSave(recipe)}
            disabled={isSaved}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300"
          >
            <Save className="w-4 h-4 mr-1" />
            {isSaved ? 'Saved' : 'Save'}
          </Button>
      </CardFooter>
    </Card>
  );
}
