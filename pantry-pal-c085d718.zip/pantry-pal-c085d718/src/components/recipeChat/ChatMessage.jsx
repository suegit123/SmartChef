
import React from 'react';
import { User, ChefHat, ShoppingCart } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import RecipeSuggestion from './RecipeSuggestion';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

function parseContent(content) {
  const recipeRegex = /```json_recipe\n([\s\S]*?)\n```/g;
  const missingIngredientsRegex = /```missing_ingredients\n([\s\S]*?)\n```/;
  
  const recipes = [];
  let match;
  while ((match = recipeRegex.exec(content)) !== null) {
    try {
      recipes.push(JSON.parse(match[1]));
    } catch (e) {
      console.error("Failed to parse recipe JSON", e);
    }
  }

  const missingMatch = content.match(missingIngredientsRegex);
  let missingIngredientsData = null;
  if (missingMatch && missingMatch[1]) {
    try {
      missingIngredientsData = JSON.parse(missingMatch[1]);
    } catch (e) {
      console.error("Failed to parse missing ingredients JSON", e);
    }
  }
  
  const conversationalText = content.replace(recipeRegex, "").replace(missingIngredientsRegex, "").trim();
  
  return { recipes, missingIngredientsData, conversationalText };
}

export default function ChatMessage({ message, onSaveRecipe, onExportRecipe, savedRecipeNames }) {
  const isUser = message.role === 'user';
  const { recipes, missingIngredientsData, conversationalText } = parseContent(message.content);

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex gap-3 max-w-[90%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
          isUser ? 'bg-gradient-to-br from-blue-500 to-blue-600' : 'bg-gradient-to-br from-emerald-500 to-emerald-600'
        }`}>
          {isUser ? (
            <User className="w-5 h-5 text-white" />
          ) : (
            <ChefHat className="w-5 h-5 text-white" />
          )}
        </div>
        <div className={`rounded-2xl px-6 py-4 shadow-md w-full ${
          isUser 
            ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white' 
            : 'bg-white text-gray-900 border border-gray-100'
        }`}>
          <div className="prose prose-sm max-w-none mb-4">
            <ReactMarkdown>{conversationalText}</ReactMarkdown>
          </div>
          <div className="space-y-4">
            {recipes.map((recipe, index) => (
              <RecipeSuggestion 
                key={index}
                recipe={recipe} 
                onSave={onSaveRecipe}
                onExport={onExportRecipe}
                isSaved={savedRecipeNames.includes(recipe.name)}
              />
            ))}
          </div>
          {missingIngredientsData && (
            <div className="mt-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="font-semibold text-orange-800">{missingIngredientsData.shopping_note}</p>
              <p className="text-sm text-orange-700 mt-1">You're missing: {missingIngredientsData.shopping_list.join(', ')}</p>
              <Link to={createPageUrl('Shopping')}>
                <Button variant="outline" size="sm" className="mt-3 border-orange-300 text-orange-700 hover:bg-orange-100">
                  <ShoppingCart className="w-4 h-4 mr-2" /> Find Ingredients
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
