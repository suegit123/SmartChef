import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Notification, User } from '@/api/entities';
import { Bell } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { createPageUrl } from '@/utils';

export default function NotificationBell() {
  const [notifications, setNotifications] = useState([]);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const fetchNotifications = async (currentUser) => {
    if (!currentUser) return;
    const data = await Notification.filter({ recipient_email: currentUser.email }, "-created_date", 20);
    setNotifications(data);
  };

  useEffect(() => {
    const init = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
        fetchNotifications(userData);
      } catch (e) {
        // Not logged in
      }
    };
    init();

    const interval = setInterval(() => init(), 30000); // Poll for new notifications every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const handleNotificationClick = async (notif) => {
    if (!notif.is_read) {
      await Notification.update(notif.id, { is_read: true });
      fetchNotifications(user);
    }
    if (notif.post_id) {
      navigate(createPageUrl(`Community`)); // Navigate to community page, user can find the post
    } else if (notif.conversation_id) {
      navigate(createPageUrl(`CommunityChat?conversationId=${notif.conversation_id}`));
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 h-4 w-4 flex items-center justify-center rounded-full bg-red-500 text-xs text-white">
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="p-2 font-semibold border-b">Notifications</div>
        <div className="max-h-96 overflow-y-auto">
          {notifications.length > 0 ? (
            notifications.map(notif => (
              <div 
                key={notif.id} 
                className={`p-3 hover:bg-gray-100 cursor-pointer ${!notif.is_read ? 'bg-emerald-50' : ''}`}
                onClick={() => handleNotificationClick(notif)}
              >
                <p className="text-sm">{notif.message}</p>
                <p className="text-xs text-gray-500 mt-1">{formatDistanceToNow(new Date(notif.created_date), { addSuffix: true })}</p>
              </div>
            ))
          ) : (
            <p className="p-4 text-sm text-gray-500 text-center">No new notifications</p>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}