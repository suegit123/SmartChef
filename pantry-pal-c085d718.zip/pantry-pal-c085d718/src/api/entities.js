import { base44 } from './base44Client';


export const Ingredient = base44.entities.Ingredient;

export const Recipe = base44.entities.Recipe;

export const CommunityPost = base44.entities.CommunityPost;

export const ChatSession = base44.entities.ChatSession;

export const Comment = base44.entities.Comment;

export const Conversation = base44.entities.Conversation;

export const Notification = base44.entities.Notification;



// auth sdk:
export const User = base44.auth;