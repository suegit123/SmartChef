import React, { useState, useEffect } from 'react';
import { Conversation, User } from '@/api/entities';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ConversationsListPage() {
  const [conversations, setConversations] = useState([]);
  const [users, setUsers] = useState({});
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadData = async () => {
      try {
        const me = await User.me();
        setCurrentUser(me);

        const myConvos = await Conversation.filter({ participants: me.email });
        setConversations(myConvos);

        const allUserEmails = myConvos.flatMap(c => c.participants);
        const uniqueUserEmails = [...new Set(allUserEmails)];
        const userProfiles = await User.filter({ email: { '$in': uniqueUserEmails } });
        
        const usersMap = userProfiles.reduce((acc, user) => {
          acc[user.email] = user;
          return acc;
        }, {});
        setUsers(usersMap);

      } catch (e) {
        console.error("Error loading conversations", e);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading) {
    return <div className="h-screen flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-emerald-500" /></div>;
  }
  
  return (
    <div className="p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
            <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('Dashboard'))}>
                <ArrowLeft />
            </Button>
            <h1 className="text-3xl font-bold">My Chats</h1>
        </div>
        
        <Card>
          <CardContent className="p-0">
            <div className="space-y-1">
              {conversations.length === 0 && (
                <p className="text-center text-gray-500 p-8">No active conversations.</p>
              )}
              {conversations.map(convo => {
                const otherUserEmail = convo.participants.find(p => p !== currentUser.email);
                const otherUser = users[otherUserEmail];
                const lastMessage = convo.messages[convo.messages.length - 1];

                if (!otherUser) return null;

                return (
                  <Link key={convo.id} to={createPageUrl(`CommunityChat?conversationId=${convo.id}`)} className="block hover:bg-gray-50">
                    <div className="flex items-center gap-4 p-4 border-b">
                      <Avatar>
                        <AvatarImage src={otherUser.profile_picture_url} />
                        <AvatarFallback>{otherUser.full_name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold">{otherUser.full_name}</p>
                        {lastMessage && (
                          <p className="text-sm text-gray-500 truncate">{lastMessage.content}</p>
                        )}
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}