
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, ExternalLink, DollarSign, MapPin, Loader2 } from "lucide-react";
import { InvokeLLM } from "@/api/integrations";

export default function ShoppingPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
        setError(null);
      },
      () => {
        setError("Unable to retrieve your location. Search results will be less specific.");
      },
      { enableHighAccuracy: true } // Added enableHighAccuracy for more precise location
    );
  }, []);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setResults([]);
    try {
      const locationContext = location ? `The user is near latitude ${location.latitude}, longitude ${location.longitude}.` : "The user's location is not available.";
      
      const response = await InvokeLLM({
        prompt: `For the item "${searchQuery}", find the price and availability at major Canadian stores like Walmart, Real Canadian Superstore, Save-On-Foods, and T&T Supermarket. ${locationContext} For each store, provide:
- store_name: The name of the store.
- product_name: The specific name of the product found.
- original_price: The listed price (e.g., "$5.99").
- original_unit: The unit for the listed price (e.g., "500g", "1L", "each").
- standardized_price_per_kg: The calculated price per kilogram. If the item is sold by volume (L/ml), calculate per liter. If sold as 'each', state 'N/A'.
- store_link: A direct link to the product on the store's website.
- availability: e.g., "In Stock", "Online Only", "Check In-Store".
- deals: Any current promotions.

Return results for at least four stores, even if the item is not available. Ensure calculations for standardized price are accurate.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            results: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  store_name: { type: "string" },
                  product_name: { type: "string" },
                  original_price: { type: "string" },
                  original_unit: { type: "string" },
                  standardized_price_per_kg: { type: "string" },
                  store_link: { type: "string" },
                  availability: { type: "string" },
                  deals: { type: "string" }
                }
              }
            }
          }
        }
      });

      setResults(response.results || []);
    } catch (error) {
      console.error("Error searching:", error);
      setError("Sorry, something went wrong while searching. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Smart Shopping</h1>
          <p className="text-gray-600 text-lg">Find the best prices for your ingredients, right where you are</p>
        </div>

        <Card className="border-none shadow-xl mb-8">
          <CardContent className="p-6">
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  placeholder="Search for ingredients (e.g., organic tomatoes, chicken breast)..."
                  className="pl-12 h-14 border-emerald-200 focus:border-emerald-500 rounded-xl text-lg"
                />
              </div>
              <Button
                onClick={handleSearch}
                disabled={loading}
                className="h-14 px-8 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-lg"
              >
                {loading ? <Loader2 className="animate-spin w-5 h-5" /> : "Search"}
              </Button>
            </div>
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
          </CardContent>
        </Card>

        {loading && (
          <div className="text-center py-16">
            <Loader2 className="w-12 h-12 text-emerald-500 animate-spin mx-auto" />
            <p className="text-gray-500 text-lg mt-4">Searching for the best deals...</p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <div className="grid md:grid-cols-2 gap-6">
            {results.map((result, index) => (
              <Card key={index} className="border-none shadow-lg hover:shadow-xl transition-shadow flex flex-col">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-emerald-500" />
                      {result.store_name}
                    </span>
                    {result.store_link && (
                      <a
                        href={result.store_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-600 hover:text-emerald-700"
                      >
                        <ExternalLink className="w-5 h-5" />
                      </a>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="space-y-3">
                    <p className="font-semibold text-gray-800">{result.product_name}</p>
                    <div className="flex items-baseline gap-2 text-2xl font-bold text-gray-900">
                      <DollarSign className="w-6 h-6 text-green-600" />
                      <span>{result.original_price}</span>
                       <span className="text-sm font-normal text-gray-500">for {result.original_unit}</span>
                    </div>
                     {result.standardized_price_per_kg !== 'N/A' && (
                        <div className="text-sm text-gray-600 font-medium p-2 bg-gray-100 rounded-md">
                          Standardized Price: {result.standardized_price_per_kg}
                        </div>
                      )}
                    <div className="text-sm text-gray-600">
                      <span className="font-medium">Availability:</span> {result.availability}
                    </div>
                    {result.deals && (
                      <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <p className="text-sm font-medium text-orange-900">🎉 {result.deals}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && results.length === 0 && searchQuery && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No results found. Try a different search term.</p>
          </div>
        )}
      </div>
    </div>
  );
}
