import React, { useState, useRef } from "react";
import { Ingredient } from "@/api/entities";
import { UploadFile, InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Camera, Upload, Loader2, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import PhotoCapture from "../components/addIngredient/PhotoCapture";
import IngredientForm from "../components/addIngredient/IngredientForm";

export default function AddIngredientPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState("upload");
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [extractedData, setExtractedData] = useState([]);
  const [processing, setProcessing] = useState(false);
  const fileInputRef = useRef(null);

  const handlePhotoCapture = (file) => {
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      handlePhotoCapture(file);
    }
  };

  const processPhoto = async () => {
    if (!photoFile) return;
    
    setProcessing(true);
    try {
      const { file_url } = await UploadFile({ file: photoFile });
      
      const result = await InvokeLLM({
        prompt: `Analyze this image and identify all food ingredients visible. For each ingredient, provide:
        - name (string)
        - category (one of: vegetables, fruits, meat, seafood, dairy, grains, seasonings, oils, herbs, other)
        - estimated quantity (string like "2 units", "500g", etc)
        - unit (string)
        
        Return as array of objects. Be specific and accurate.`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            ingredients: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  category: { type: "string" },
                  quantity: { type: "string" },
                  unit: { type: "string" }
                }
              }
            }
          }
        }
      });

      const ingredientsWithPhoto = result.ingredients.map(ing => ({
        ...ing,
        photo_url: file_url,
        purchase_date: new Date().toISOString().split('T')[0]
      }));

      setExtractedData(ingredientsWithPhoto);
      setStep("edit");
    } catch (error) {
      console.error("Error processing photo:", error);
      alert("Failed to process the photo. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const handleSave = async (ingredients) => {
    setProcessing(true);
    try {
      await Ingredient.bulkCreate(ingredients);
      navigate(createPageUrl("Ingredients"));
    } catch (error) {
      console.error("Error saving ingredients:", error);
      alert("Failed to save ingredients. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Add Ingredients</h1>
          <p className="text-gray-600 text-lg">Take a photo and let AI identify your ingredients</p>
        </div>

        {step === "upload" && (
          <Card className="border-none shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="w-6 h-6 text-emerald-500" />
                Capture Your Ingredients
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!photoPreview ? (
                <>
                  <PhotoCapture onCapture={handlePhotoCapture} />
                  
                  <div className="mt-6">
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-200"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-4 bg-white text-gray-500">or</span>
                      </div>
                    </div>

                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    
                    <Button
                      variant="outline"
                      className="w-full mt-6 h-12 border-2 border-dashed border-emerald-300 hover:bg-emerald-50"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="w-5 h-5 mr-2" />
                      Upload from Gallery
                    </Button>
                  </div>
                </>
              ) : (
                <div className="space-y-6">
                  <div className="relative rounded-xl overflow-hidden">
                    <img src={photoPreview} alt="Preview" className="w-full h-96 object-cover" />
                  </div>
                  
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => {
                        setPhotoFile(null);
                        setPhotoPreview(null);
                      }}
                    >
                      Retake Photo
                    </Button>
                    <Button
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700"
                      onClick={processPhoto}
                      disabled={processing}
                    >
                      {processing ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Check className="w-5 h-5 mr-2" />
                          Analyze Photo
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {step === "edit" && (
          <IngredientForm
            ingredients={extractedData}
            onSave={handleSave}
            onCancel={() => {
              setStep("upload");
              setPhotoFile(null);
              setPhotoPreview(null);
              setExtractedData([]);
            }}
            processing={processing}
          />
        )}
      </div>
    </div>
  );
}