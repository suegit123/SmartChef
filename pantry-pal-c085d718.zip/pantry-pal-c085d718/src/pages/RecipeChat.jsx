
import React, { useState, useEffect, useRef } from "react";
import { Recipe, Ingredient, User, ChatSession } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, ChefHat, Loader2 } from "lucide-react";
import ChatMessage from "../components/recipeChat/ChatMessage";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function RecipeChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [ingredients, setIngredients] = useState([]);
  const [user, setUser] = useState(null);
  const [chatSession, setChatSession] = useState(null);
  const [savedRecipeNames, setSavedRecipeNames] = useState([]);
  const messagesEndRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [ingredientsData, userData, savedRecipes] = await Promise.all([
        Ingredient.list(),
        User.me(),
        Recipe.list()
      ]);
      setIngredients(ingredientsData);
      setUser(userData);
      setSavedRecipeNames(savedRecipes.map(r => r.name));

      const params = new URLSearchParams(location.search);
      const useItems = params.get('use_items');
      
      const sessions = await ChatSession.filter({ created_by: userData.email }, '-created_date', 1);
      if (sessions.length > 0) {
        setChatSession(sessions[0]);
        setMessages(sessions[0].messages);
      } else {
        const welcomeMessage = {
          role: "assistant",
          content: "Hi! I'm your personal chef assistant. I can suggest recipes based on your available ingredients, equipment, and dietary preferences. What would you like to cook today?"
        };
        setMessages([welcomeMessage]);
        const newSession = await ChatSession.create({ messages: [welcomeMessage] });
        setChatSession(newSession);
      }

      if (useItems) {
        setInput(`Suggest recipes using these expiring items: ${useItems}`);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = { role: "user", content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const ingredientsList = ingredients.map(i => `${i.name} (${i.quantity || 'some'} ${i.unit || ''})`).join(", ");
      const equipment = user?.equipment?.join(", ") || "basic kitchen tools";
      const dietary = user?.dietary_restrictions?.join(", ") || "none";
      const allergies = user?.allergies?.join(", ") || "none";

      const prompt = `You are a professional chef assistant. The user has these ingredients: ${ingredientsList}.
Available equipment: ${equipment}.
The user has the following STRICT dietary restrictions, which you MUST follow: ${dietary}.
The user has these SEVERE allergies, which you MUST AVOID: ${allergies}.

User request: "${input}"

Generate two distinct recipe suggestions based on the user's request.
1.  **First Recipe:** MUST prioritize using ONLY the ingredients the user already has. This recipe should be creative and make the most of the available items.
2.  **Second Recipe:** Can be a more ideal or standard recipe that might require a few extra ingredients. If this recipe needs ingredients the user doesn't have, you MUST identify them.

For each recipe, embed a JSON object in your response using a markdown code block with the language "json_recipe". The JSON must contain: name, description, ingredients (array of strings, including quantities), instructions (array of strings), prep_time, cook_time, servings, calories, cuisine, and equipment_needed.

After the JSON for the second recipe, if it has missing ingredients, add a "missing_ingredients" markdown block with a "shopping_list" (an array of the missing items) and a "shopping_note".

Example for the second recipe with missing items:
\`\`\`json_recipe
{
  "name": "Caprese Salad",
  "description": "A simple and fresh Italian salad.",
  "ingredients": ["2 large Tomatoes", "200g Fresh Mozzarella", "1/4 cup Fresh Basil", "2 tbsp Olive Oil", "1 tbsp Balsamic Glaze"],
  "instructions": ["Slice tomatoes and mozzarella.", "Arrange on a plate, alternating slices.", "Tuck basil leaves in between.", "Drizzle with olive oil and balsamic glaze."],
  "prep_time": "10 mins",
  "cook_time": "0 mins",
  "servings": 2,
  "calories": 300,
  "cuisine": "Italian",
  "equipment_needed": ["Knife", "Cutting board"]
}
\`\`\`
\`\`\`missing_ingredients
{
  "shopping_list": ["Fresh Mozzarella", "Fresh Basil", "Balsamic Glaze"],
  "shopping_note": "You seem to be missing a few items for this recipe! You can find them at a local store."
}
\`\`\`

After all JSON blocks, continue with a friendly, conversational message presenting both recipes.`;

      const response = await InvokeLLM({
        prompt: prompt,
        add_context_from_internet: true
      });

      const assistantMessage = { role: "assistant", content: response };
      const finalMessages = [...newMessages, assistantMessage];
      setMessages(finalMessages);
      await ChatSession.update(chatSession.id, { messages: finalMessages });

    } catch (error) {
      console.error("Error getting recipe:", error);
      const errorMessage = { role: "assistant", content: "Sorry, I encountered an error. Please try again." };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveRecipe = async (recipeData) => {
    try {
      if (savedRecipeNames.includes(recipeData.name)) {
        const infoMessage = { role: "assistant", content: `You've already saved "${recipeData.name}" to your collection.` };
        const updatedMessages = [...messages, infoMessage];
        setMessages(updatedMessages);
        await ChatSession.update(chatSession.id, { messages: updatedMessages });
        return;
      }

      await Recipe.create({
        ...recipeData,
        ingredients_used: recipeData.ingredients,
        instructions: recipeData.instructions || [],
      });
      setSavedRecipeNames(prev => [...prev, recipeData.name]);
      const successMessage = { role: "assistant", content: `Great! I've saved "${recipeData.name}" to your collection.` };
      const updatedMessages = [...messages, successMessage];
      setMessages(updatedMessages);
      await ChatSession.update(chatSession.id, { messages: updatedMessages });
    } catch (error) {
      console.error("Error saving recipe:", error);
      const errorMessage = { role: "assistant", content: "Sorry, I had trouble saving that recipe." };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const handleExportRecipe = (recipeData) => {
    const recipeQuery = encodeURIComponent(JSON.stringify(recipeData));
    navigate(`${createPageUrl("RecipePrint")}?recipe=${recipeQuery}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
        <div className="mb-6">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center gap-3">
            <ChefHat className="w-10 h-10 text-emerald-500" />
            Recipe Chat
          </h1>
          <p className="text-gray-600 text-lg">Your AI-powered culinary assistant</p>
        </div>

        <Card className="flex-1 border-none shadow-xl flex flex-col overflow-hidden">
          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message, index) => (
              <ChatMessage 
                key={index} 
                message={message}
                onSaveRecipe={handleSaveRecipe}
                onExportRecipe={handleExportRecipe}
                savedRecipeNames={savedRecipeNames}
              />
            ))}
            {loading && !chatSession && (
               <div className="flex justify-start">
                <div className="bg-emerald-100 rounded-2xl px-6 py-4 flex items-center gap-3">
                  <Loader2 className="w-5 h-5 animate-spin text-emerald-600" />
                  <span className="text-emerald-700">Loading your chat...</span>
                </div>
              </div>
            )}
            {loading && chatSession && (
              <div className="flex justify-start">
                <div className="bg-emerald-100 rounded-2xl px-6 py-4 flex items-center gap-3">
                  <Loader2 className="w-5 h-5 animate-spin text-emerald-600" />
                  <span className="text-emerald-700">Thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </CardContent>

          <div className="p-6 border-t border-gray-100 bg-white">
            <div className="flex gap-3">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask for a recipe, cooking tips, or substitutions..."
                className="flex-1 h-12 border-emerald-200 focus:border-emerald-500 rounded-xl"
                disabled={loading}
              />
              <Button
                onClick={handleSend}
                disabled={loading || !input.trim()}
                className="h-12 px-6 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-lg"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
