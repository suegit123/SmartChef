
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Flame, Users, Utensils, CheckSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function RecipePrintPage() {
  const [recipe, setRecipe] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const recipeData = params.get('recipe');
    if (recipeData) {
      try {
        setRecipe(JSON.parse(decodeURIComponent(recipeData)));
      } catch (e) {
        console.error("Failed to parse recipe data", e);
      }
    }
  }, [location]);

  useEffect(() => {
    if (recipe) {
      setTimeout(() => window.print(), 500);
    }
  }, [recipe]);

  if (!recipe) {
    return <div className="p-8 text-center">Loading recipe for printing...</div>;
  }

  return (
    <div className="bg-white p-4 sm:p-8 print:p-0">
      <style>{`
        @media print {
          body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .no-print { display: none; }
        }
      `}</style>
      <Button onClick={() => window.print()} className="mb-8 no-print bg-emerald-600">
        Print Recipe
      </Button>

      <Card className="max-w-4xl mx-auto border-none print:shadow-none print:border-none">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl font-bold mb-4">{recipe.name}</CardTitle>
          {recipe.description && (
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">{recipe.description}</p>
          )}
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 my-8 p-4 bg-gray-50 rounded-lg">
            {recipe.cook_time && <span className="flex items-center gap-2 text-lg"><Clock className="w-5 h-5 text-emerald-600" />{recipe.cook_time}</span>}
            {recipe.calories && <span className="flex items-center gap-2 text-lg"><Flame className="w-5 h-5 text-orange-600" />{recipe.calories} cal</span>}
            {recipe.servings && <span className="flex items-center gap-2 text-lg"><Users className="w-5 h-5 text-blue-600" />Serves {recipe.servings}</span>}
            {recipe.cuisine && <span className="flex items-center gap-2 text-lg"><Utensils className="w-5 h-5 text-purple-600" />{recipe.cuisine}</span>}
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-1">
              <h3 className="text-2xl font-semibold mb-4 border-b pb-2">Ingredients</h3>
              <ul className="space-y-2">
                {recipe.ingredients.map((ing, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckSquare className="w-5 h-5 text-emerald-500 mt-1 flex-shrink-0" />
                    <span>{ing}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="md:col-span-2">
              <h3 className="text-2xl font-semibold mb-4 border-b pb-2">Instructions</h3>
              <ol className="space-y-4">
                {recipe.instructions.map((step, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center font-bold">{i + 1}</div>
                    <p className="pt-1">{step}</p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
