import React, { useState, useEffect } from "react";
import { CommunityPost, User } from "@/api/entities";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CommunityPostCard from "../components/community/CommunityPostCard";

export default function CommunityPage() {
  const [posts, setPosts] = useState([]);
  const [users, setUsers] = useState({});
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [postsData, usersData, currentUserData] = await Promise.all([
      CommunityPost.filter({ status: "available" }, "-created_date"),
      User.list(),
      User.me(),
    ]);

    const usersMap = usersData.reduce((acc, user) => {
      acc[user.email] = user;
      return acc;
    }, {});

    setPosts(postsData);
    setUsers(usersMap);
    setCurrentUser(currentUserData);
  };
  
  const myPosts = posts.filter(p => p.created_by === currentUser?.email);
  const nearbyOffers = posts.filter(p => p.created_by !== currentUser?.email);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Community Sharing</h1>
            <p className="text-gray-600 text-lg">Share surplus ingredients and reduce food waste</p>
          </div>
        </div>

        <Tabs defaultValue="nearby" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-emerald-100/60 p-1.5 rounded-xl">
            <TabsTrigger value="nearby" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg">Nearby Offers</TabsTrigger>
            <TabsTrigger value="shared" className="data-[state=active]:bg-white data-[state=active]:shadow-md rounded-lg">My Shared Items</TabsTrigger>
          </TabsList>
          
          <TabsContent value="nearby" className="mt-6">
            <div className="space-y-6">
              {nearbyOffers.length > 0 ? (
                nearbyOffers.map((post) => (
                  <CommunityPostCard
                    key={post.id}
                    post={post}
                    postUser={users[post.created_by]}
                    currentUser={currentUser}
                    onUpdate={loadData}
                  />
                ))
              ) : (
                <div className="text-center py-16 text-gray-500">No ingredients available nearby.</div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="shared" className="mt-6">
            <div className="space-y-6">
              {myPosts.length > 0 ? (
                myPosts.map((post) => (
                  <CommunityPostCard
                    key={post.id}
                    post={post}
                    postUser={users[post.created_by]}
                    currentUser={currentUser}
                    onUpdate={loadData}
                  />
                ))
              ) : (
                <div className="text-center py-16 text-gray-500">You haven't shared any items yet.</div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}