import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Save, X } from "lucide-react";

const EQUIPMENT_OPTIONS = [
  { id: "oven", label: "Oven" }, { id: "air_fryer", label: "Air Fryer" },
  { id: "stove", label: "Stove" }, { id: "baking_plate", label: "Baking Plate" },
  { id: "microwave", label: "Microwave" }, { id: "grill", label: "Grill" },
  { id: "pressure_cooker", label: "Pressure Cooker" }, { id: "slow_cooker", label: "Slow Cooker" },
  { id: "blender", label: "Blender" }, { id: "stand_mixer", label: "Stand Mixer" },
  { id: "food_processor", label: "Food Processor" }, { id: "toaster", label: "Toaster" }
];

const DIETARY_OPTIONS = [
  { id: "vegetarian", label: "Vegetarian" }, { id: "vegan", label: "Vegan" },
  { id: "gluten_free", label: "Gluten-Free" }, { id: "dairy_free", label: "Dairy-Free" },
  { id: "keto", label: "Keto" }, { id: "paleo", label: "Paleo" },
  { id: "halal", label: "Halal" }, { id: "pescetarian", label: "Pescetarian" }
];

const ALLERGY_OPTIONS = [
  { id: "peanuts", label: "Peanuts" }, { id: "tree_nuts", label: "Tree Nuts" },
  { id: "milk", label: "Milk" }, { id: "eggs", label: "Eggs" },
  { id: "soy", label: "Soy" }, { id: "wheat", label: "Wheat" },
  { id: "fish", label: "Fish" }, { id: "shellfish", label: "Shellfish" }
];

export default function SettingsPage() {
  const [user, setUser] = useState(null);
  const [equipment, setEquipment] = useState([]);
  const [dietaryRestrictions, setDietaryRestrictions] = useState([]);
  const [allergies, setAllergies] = useState([]);
  const [newDietary, setNewDietary] = useState("");
  const [newAllergy, setNewAllergy] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const userData = await User.me();
    setUser(userData);
    setEquipment(userData.equipment || []);
    setDietaryRestrictions(userData.dietary_restrictions || []);
    setAllergies(userData.allergies || []);
  };

  const toggleItem = (list, setList, item) => {
    setList(prev =>
      prev.includes(item)
        ? prev.filter(i => i !== item)
        : [...prev, item]
    );
  };

  const addCustomItem = (list, setList, newItem, setNewItem) => {
    if (newItem.trim() && !list.includes(newItem.trim())) {
      setList([...list, newItem.trim()]);
      setNewItem("");
    }
  };

  const removeItem = (setList, item) => {
    setList(prev => prev.filter(i => i !== item));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await User.updateMyUserData({
        equipment,
        dietary_restrictions: dietaryRestrictions,
        allergies
      });
      alert("Settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      alert("Failed to save settings. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Preference & Restriction</h1>
          <p className="text-gray-600 text-lg">Customize your kitchen preferences</p>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-lg">
            <CardHeader><CardTitle>Kitchen Equipment</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {EQUIPMENT_OPTIONS.map((item) => (
                  <div key={item.id} className="flex items-center space-x-2">
                    <Checkbox id={`eq-${item.id}`} checked={equipment.includes(item.id)} onCheckedChange={() => toggleItem(equipment, setEquipment, item.id)} />
                    <label htmlFor={`eq-${item.id}`} className="text-sm font-medium leading-none cursor-pointer">{item.label}</label>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardHeader><CardTitle>Dietary Restrictions</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {DIETARY_OPTIONS.map((item) => (
                  <div key={item.id} className="flex items-center space-x-2">
                    <Checkbox id={`diet-${item.id}`} checked={dietaryRestrictions.includes(item.id)} onCheckedChange={() => toggleItem(dietaryRestrictions, setDietaryRestrictions, item.id)} />
                    <label htmlFor={`diet-${item.id}`} className="text-sm font-medium leading-none cursor-pointer">{item.label}</label>
                  </div>
                ))}
              </div>
              <Label>Custom Restrictions</Label>
              <div className="flex gap-3 mb-4">
                <Input value={newDietary} onChange={(e) => setNewDietary(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && addCustomItem(dietaryRestrictions, setDietaryRestrictions, newDietary, setNewDietary)} placeholder="Add custom restriction..." />
                <Button onClick={() => addCustomItem(dietaryRestrictions, setDietaryRestrictions, newDietary, setNewDietary)} variant="outline">Add</Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {dietaryRestrictions.map((item) => (
                  <Badge key={item} variant="secondary" className="text-sm px-3 py-1">
                    {item}
                    <button onClick={() => removeItem(setDietaryRestrictions, item)} className="ml-2 hover:text-red-600"><X className="w-3 h-3" /></button>
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardHeader><CardTitle>Food Allergies</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {ALLERGY_OPTIONS.map((item) => (
                  <div key={item.id} className="flex items-center space-x-2">
                    <Checkbox id={`allergy-${item.id}`} checked={allergies.includes(item.id)} onCheckedChange={() => toggleItem(allergies, setAllergies, item.id)} />
                    <label htmlFor={`allergy-${item.id}`} className="text-sm font-medium leading-none cursor-pointer">{item.label}</label>
                  </div>
                ))}
              </div>
              <Label>Custom Allergies</Label>
              <div className="flex gap-3 mb-4">
                <Input value={newAllergy} onChange={(e) => setNewAllergy(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && addCustomItem(allergies, setAllergies, newAllergy, setNewAllergy)} placeholder="Add custom allergy..." />
                <Button onClick={() => addCustomItem(allergies, setAllergies, newAllergy, setNewAllergy)} variant="outline">Add</Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {allergies.map((item) => (
                  <Badge key={item} variant="destructive" className="text-sm px-3 py-1">
                    {item}
                    <button onClick={() => removeItem(setAllergies, item)} className="ml-2 hover:text-white"><X className="w-3 h-3" /></button>
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={saving} className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-lg px-8" size="lg">
              {saving ? "Saving..." : <><Save className="w-5 h-5 mr-2" />Save Settings</>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}