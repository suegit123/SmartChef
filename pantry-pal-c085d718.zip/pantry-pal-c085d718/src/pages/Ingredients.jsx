import React, { useState, useEffect } from "react";
import { Ingredient, User } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Plus, SlidersHorizontal } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import IngredientCard from "../components/ingredients/IngredientCard";
import IngredientDetailsDialog from "../components/ingredients/IngredientDetailsDialog";

export default function IngredientsPage() {
  const [ingredients, setIngredients] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [selectedIngredient, setSelectedIngredient] = useState(null);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUserAndIngredients();
  }, []);

  const loadUserAndIngredients = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      if (userData) {
        const data = await Ingredient.filter({ created_by: userData.email }, "-created_date");
        setIngredients(data);
      } else {
        setIngredients([]);
      }
    } catch (error) {
      console.error("Error loading user and ingredients:", error);
      setIngredients([]);
    }
  };

  const handleDelete = async (id) => {
    await Ingredient.delete(id);
    if (user) {
      const data = await Ingredient.filter({ created_by: user.email }, "-created_date");
      setIngredients(data);
    } else {
      loadUserAndIngredients();
    }
    setSelectedIngredient(null);
  };

  const handleUpdate = () => {
    loadUserAndIngredients(); // Reload all ingredients
  }

  const filteredIngredients = ingredients.filter(ingredient => {
    const matchesSearch = ingredient.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === "all" || ingredient.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = ["all", "vegetables", "fruits", "meat", "seafood", "dairy", "grains", "seasonings", "oils", "herbs", "other"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">My Pantry</h1>
            <p className="text-gray-600 text-lg">{ingredients.length} ingredients in your kitchen</p>
          </div>
          <Link to={createPageUrl("AddIngredient")}>
            <Button className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-lg">
              <Plus className="w-5 h-5 mr-2" />
              Add Ingredients
            </Button>
          </Link>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search ingredients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-12 border-emerald-200 focus:border-emerald-500 rounded-xl"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-48 h-12 border-emerald-200 rounded-xl">
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {filteredIngredients.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg mb-4">
              {searchQuery || categoryFilter !== "all" 
                ? "No ingredients found matching your search" 
                : "Your pantry is empty"}
            </p>
            <Link to={createPageUrl("AddIngredient")}>
              <Button variant="outline" className="border-emerald-500 text-emerald-600 hover:bg-emerald-50">
                Add Your First Ingredients
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredIngredients.map((ingredient) => (
              <IngredientCard
                key={ingredient.id}
                ingredient={ingredient}
                onClick={() => setSelectedIngredient(ingredient)}
              />
            ))}
          </div>
        )}

        {selectedIngredient && (
          <IngredientDetailsDialog
            ingredient={selectedIngredient}
            onClose={() => setSelectedIngredient(null)}
            onDelete={handleDelete}
            onUpdate={handleUpdate}
          />
        )}
      </div>
    </div>
  );
}