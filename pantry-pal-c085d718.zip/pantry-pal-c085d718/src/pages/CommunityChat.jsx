import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Conversation, User, Notification } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, ArrowLeft, Loader2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { createPageUrl } from '@/utils';

export default function CommunityChatPage() {
  const [conversation, setConversation] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [otherUser, setOtherUser] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();
  const messagesEndRef = useRef(null);

  const fetchChatData = async () => {
      try {
        setLoading(true);
        const params = new URLSearchParams(location.search);
        const conversationId = params.get('conversationId');
        
        if (!conversationId) {
          setLoading(false);
          return;
        }

        const [convoData, currentUserData] = await Promise.all([
          Conversation.get(conversationId),
          User.me()
        ]);

        setConversation(convoData);
        setCurrentUser(currentUserData);

        const otherUserEmail = convoData.participants.find(p => p !== currentUserData.email);
        if (otherUserEmail) {
          const otherUsers = await User.filter({ email: otherUserEmail });
          if (otherUsers.length > 0) {
            setOtherUser(otherUsers[0]);
          }
        }
      } catch (error) {
        console.error("Failed to load chat data", error);
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    fetchChatData();
    const interval = setInterval(fetchChatData, 5000); // Poll for new messages every 5 seconds
    return () => clearInterval(interval);
  }, [location.search]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation?.messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversation) return;

    const message = {
      sender: currentUser.email,
      content: newMessage,
      timestamp: new Date().toISOString(),
    };

    const updatedMessages = [...(conversation.messages || []), message];
    
    // Optimistic update
    setConversation(prev => ({ ...prev, messages: updatedMessages }));
    setNewMessage('');
    
    await Conversation.update(conversation.id, { messages: updatedMessages });

    // Create a notification for the other user
    if (otherUser) {
      await Notification.create({
        recipient_email: otherUser.email,
        actor_email: currentUser.email,
        type: 'message',
        conversation_id: conversation.id,
        message: `You have a new message from ${currentUser.full_name}.`
      });
    }
  };

  if (loading && !conversation) {
    return <div className="h-screen w-full flex justify-center items-center"><Loader2 className="animate-spin h-8 w-8 text-emerald-600"/></div>;
  }
  
  if (!conversation || !currentUser || !otherUser) {
    return <div className="p-8 text-center text-red-500">Could not load chat session.</div>;
  }

  return (
    <div className="p-4 md:p-8 h-screen bg-gray-50 flex justify-center items-center">
      <Card className="w-full max-w-2xl h-[90vh] flex flex-col shadow-2xl">
        <CardHeader className="flex flex-row items-center gap-4 border-b">
          <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('Community'))}><ArrowLeft/></Button>
          <Avatar>
            <AvatarImage src={otherUser.profile_picture_url} />
            <AvatarFallback>{otherUser.full_name.charAt(0)}</AvatarFallback>
          </Avatar>
          <CardTitle>Chat with {otherUser.full_name}</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
          {conversation.messages.map((msg, index) => (
            <div key={index} className={`flex ${msg.sender === currentUser.email ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.sender === currentUser.email ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'}`}>
                {msg.content}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </CardContent>
        <div className="p-4 border-t">
          <div className="flex items-center gap-2">
            <Input
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <Button onClick={handleSendMessage} size="icon" className="bg-emerald-600 hover:bg-emerald-700">
              <Send className="w-4 h-4"/>
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}