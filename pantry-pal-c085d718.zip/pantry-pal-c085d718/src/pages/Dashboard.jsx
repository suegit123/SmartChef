
import React, { useState, useEffect } from "react";
import { Ingredient, Recipe, User } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";
import { differenceInDays } from "date-fns";
import QuickStats from "../components/dashboard/QuickStats";
import ExpiringItems from "../components/dashboard/ExpiringItems";
import RecentRecipes from "../components/dashboard/RecentRecipes";

export default function Dashboard() {
  const [ingredients, setIngredients] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData) {
          const [ingredientsData, recipesData] = await Promise.all([
            Ingredient.filter({ created_by: userData.email }, "-created_date", 100),
            Recipe.filter({ created_by: userData.email }, "-created_date", 5),
          ]);
          setIngredients(ingredientsData);
          setRecipes(recipesData);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteRecipe = async (recipeId) => {
      await Recipe.delete(recipeId);
      loadData(); // Reload all data to reflect the change
  }

  const expiringItems = ingredients.filter(item => {
    if (!item.expiry_date) return false;
    const daysUntilExpiry = differenceInDays(new Date(item.expiry_date), new Date());
    return daysUntilExpiry <= 3 && daysUntilExpiry >= 0;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-orange-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Welcome back{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''}
          </h1>
          <p className="text-gray-600 text-lg">Let's see what's cooking in your kitchen today</p>
        </div>

        <QuickStats 
          totalIngredients={ingredients.length}
          expiringCount={expiringItems.length}
          recipesCount={recipes.length}
        />

        {expiringItems.length === 0 && ingredients.length === 0 && (
          <Card className="mb-8 border-2 border-dashed border-emerald-300 bg-emerald-50/50">
            <CardContent className="p-8 text-center">
              <Camera className="w-16 h-16 mx-auto mb-4 text-emerald-500" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Start Building Your Pantry</h3>
              <p className="text-gray-600 mb-6">Take photos of your ingredients to get started with AI-powered recipe suggestions</p>
              <Link to={createPageUrl("AddIngredient")}>
                <Button className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 shadow-lg">
                  <Camera className="w-5 h-5 mr-2" />
                  Add Your First Ingredients
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ExpiringItems items={expiringItems} />
          </div>
          
          <div>
            <RecentRecipes recipes={recipes} onDelete={handleDeleteRecipe} />
          </div>
        </div>

        {ingredients.length > 0 && (
          <Card className="mt-6 bg-gradient-to-r from-orange-500 to-orange-600 text-white border-none shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold mb-2">Ready to Cook?</h3>
                  <p className="text-orange-100">Ask our AI chef for personalized recipe ideas</p>
                </div>
                <Link to={createPageUrl("RecipeChat")}>
                  <Button variant="secondary" className="bg-white text-orange-600 hover:bg-orange-50">
                    Get Recipe Ideas
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
