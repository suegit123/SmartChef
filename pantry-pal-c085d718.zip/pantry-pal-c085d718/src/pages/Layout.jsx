

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Package, Camera, MessageSquare, ShoppingCart, Users, Settings, LogOut, ChefHat, MessageSquare as MessageSquareIcon } from "lucide-react";
import NotificationBell from "@/components/layout/NotificationBell";
import { User } from "@/api/entities";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: Home },
  { title: "My Pantry", url: createPageUrl("Ingredients"), icon: Package },
  { title: "Add Items", url: createPageUrl("AddIngredient"), icon: Camera },
  { title: "Recipe Chat", url: createPageUrl("RecipeChat"), icon: MessageSquare },
  { title: "Shopping", url: createPageUrl("Shopping"), icon: ShoppingCart },
  { title: "Community", url: createPageUrl("Community"), icon: Users },
  { title: "Preference & Restriction", url: createPageUrl("Settings"), icon: Settings },
];

export default function Layout({ children }) {
  const location = useLocation();

  const handleLogout = async () => {
    await User.logout();
    window.location.reload(); // Reload to reflect logged-out state
  };

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --primary: 142 71% 45%;
          --primary-foreground: 0 0% 100%;
          --secondary: 38 92% 50%;
          --secondary-foreground: 0 0% 100%;
          --accent: 142 76% 36%;
          --accent-foreground: 0 0% 100%;
          --muted: 142 25% 96%;
          --muted-foreground: 142 8% 45%;
        }
      `}</style>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-emerald-50 via-white to-orange-50">
        <Sidebar className="border-r border-emerald-100 bg-white/80 backdrop-blur-sm flex flex-col">
          <SidebarHeader className="border-b border-emerald-100 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                <ChefHat className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-xl text-gray-900">SmartChef</h2>
                <p className="text-xs text-emerald-600">Save Food! Save Time!</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3 flex-1">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`rounded-xl transition-all duration-200 ${
                          location.pathname === item.url 
                            ? 'bg-gradient-to-r from-emerald-500 to-emerald-600 text-white shadow-md' 
                            : 'hover:bg-emerald-50 text-gray-700'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <div className="p-3 border-t border-emerald-100">
            <SidebarMenuItem>
              <SidebarMenuButton onClick={handleLogout} className="rounded-xl hover:bg-red-50 text-red-600 w-full">
                <div className="flex items-center gap-3 px-4 py-3">
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Sign Out</span>
                </div>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </div>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-sm border-b border-emerald-100 px-6 py-4 flex justify-between items-center">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-emerald-50 p-2 rounded-lg transition-colors duration-200 md:hidden" />
              <h1 className="text-xl font-bold text-gray-900 md:hidden">SmartChef</h1>
            </div>
            <div className="flex items-center gap-4">
              <Link to={createPageUrl("ConversationsList")}>
                  <MessageSquareIcon className="w-6 h-6 text-gray-600 hover:text-emerald-600 transition-colors"/>
              </Link>
              <NotificationBell />
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

